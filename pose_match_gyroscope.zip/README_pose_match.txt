
POSE MATCH (Giroscopio) – Instrucciones de publicación HTTPS

¿Por qué HTTPS?
iOS solo muestra el permiso del giroscopio (Motion & Orientation) cuando la página se sirve por HTTPS o desde un servidor local. Por eso, al abrir el archivo local, puede que no salga el prompt.

Opción A: GitHub Pages (gratis)
1) Crea una cuenta en GitHub (si aún no tienes).
2) Crea un repositorio nuevo llamado, por ejemplo, pose-match.
3) Sube el archivo: pose_match_gyroscope.html
4) Ve a Settings > Pages > “Branch: main (root)” > Save.
5) Espera ~1-2 minutos. Tu web quedará en: https://TU_USUARIO.github.io/pose-match/pose_match_gyroscope.html
6) Ábrela en Safari (iPhone). Toca “Empezar” y permite el acceso al giroscopio.

Opción B: Netlify (muy simple)
1) Entra a https://app.netlify.com y crea cuenta.
2) “Add new site” > “Deploy manually”.
3) Arrastra el archivo pose_match_gyroscope.html a la zona de despliegue.
4) Abre la URL que te da Netlify (https://tu-sitio.netlify.app/pose_match_gyroscope.html).
5) En iPhone, toca “Empezar” y acepta el permiso.

Opción C: Servidor local en iPhone/iPad
1) Instala una app tipo “Kodex” o “Textastic” que trae servidor local (localhost).
2) Copia el archivo pose_match_gyroscope.html a esa app.
3) Sirve el archivo desde su servidor local y abre el enlace en Safari.
4) Si no aparece el prompt, ve a Ajustes > Safari > Privacidad y seguridad > activar “Permitir movimiento y orientación”.

Consejos iOS:
- Si no aparece el prompt, activa manualmente: Ajustes > Safari > “Permitir movimiento y orientación”.
- Tras activar, recarga la página.
- Mantén el teléfono en orientación vertical al iniciar para una calibración más estable.

Archivo del juego: pose_match_gyroscope.html
